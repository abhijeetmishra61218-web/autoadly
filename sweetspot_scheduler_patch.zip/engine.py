# engine.py
import asyncio
import logging
import random
from telethon import TelegramClient
from telethon.sessions import StringSession
from telethon.tl.functions.messages import ForwardMessagesRequest
from telethon.errors import FloodWaitError, ChatWriteForbiddenError, UserBannedInChannelError
import database as db

API_ID = 37701222
API_HASH = "5e137a9ed23be5787dcdd9a92d9e48df"

POST_INTERVAL_CYCLE = [60, 120, 180, 240]  # rotates 1min -> 2min -> 3min -> 4min -> repeat, per account,
                                            # so posting timing looks less robotic/synchronized to Telegram's spam detection

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ad_engine")

_clients = {}

async def get_client(ad_account_id: int) -> TelegramClient:
    if ad_account_id in _clients:
        return _clients[ad_account_id]
    account = await db.get_ad_account_session(ad_account_id)
    client = TelegramClient(StringSession(account["session_string"]), API_ID, API_HASH)
    await client.connect()
    # Populate this connection's entity cache with every chat the account is a member of.
    # Without this, resolving a chat by numeric ID (t.me/c/... links) fails on a fresh
    # connection even though the account genuinely has access to it.
    await client.get_dialogs()
    _clients[ad_account_id] = client
    return client

async def disconnect_and_forget_client(ad_account_id: int):
    """Disconnects and drops a cached client (used when an account is fully
       removed from the system via /removeno, so no stale connection lingers)."""
    client = _clients.pop(ad_account_id, None)
    if client:
        try:
            await client.disconnect()
        except Exception as e:
            print(f"[engine] error disconnecting client for account {ad_account_id}: {e}")

def _extract_new_message_id(result):
    """Pulls the new message's id out of a ForwardMessagesRequest response, if present."""
    try:
        updates = getattr(result, "updates", None)
        if not updates:
            return None
        for upd in updates:
            msg = getattr(upd, "message", None)
            if msg is not None and hasattr(msg, "id"):
                return msg.id
    except Exception:
        pass
    return None

def _build_message_link(marketplace, msg_id):
    """Builds a real link to the message as posted in the DESTINATION marketplace,
       not the source ad channel. Uses the public username if the marketplace has
       one (and it's not just a numeric placeholder), otherwise falls back to the
       private t.me/c/<id>/<msg> format using the marketplace's chat_id."""
    username = marketplace["chat_username"]
    has_real_username = username and not str(username).lstrip("-").isdigit()
    if has_real_username:
        return f"https://t.me/{username}/{msg_id}" if msg_id else f"https://t.me/{username}"
    chat_id_str = str(marketplace["chat_id"])
    if chat_id_str.startswith("-100"):
        chat_id_str = chat_id_str[4:]
    elif chat_id_str.startswith("-"):
        chat_id_str = chat_id_str[1:]
    return f"https://t.me/c/{chat_id_str}/{msg_id}" if msg_id else f"https://t.me/c/{chat_id_str}"

VISIBILITY_CHECK_DELAY_SECONDS = 90
VISIBILITY_RECENT_WINDOW = 15  # message must still be within the last N messages to count as "visible"

async def is_still_visible(client, target, msg_id):
    """True if a posted message still exists and hasn't been buried under a
       flood of newer messages (same visibility rule used for auto-demotion)."""
    if msg_id is None:
        return False
    msg = await client.get_messages(target, ids=msg_id)
    if msg is None:
        return False
    async for m in client.iter_messages(target, limit=VISIBILITY_RECENT_WINDOW):
        if m.id == msg_id:
            return True
    return False

async def _check_visibility_later(client, marketplace, msg_id, target):
    """Fire-and-forget: waits a bit, then checks whether a just-posted message
       is still visible (exists AND not buried under a flood of newer messages).
       Feeds the result into the marketplace's automatic quality tracking."""
    if msg_id is None:
        return
    try:
        await asyncio.sleep(VISIBILITY_CHECK_DELAY_SECONDS)
        buried = not await is_still_visible(client, target, msg_id)
        newly_demoted = await db.record_visibility_check(marketplace["id"], buried)
        if newly_demoted:
            logger.info(f"Marketplace {marketplace['id']} ({marketplace.get('chat_username')}) auto-demoted to low quality (posts consistently buried).")
    except Exception as e:
        logger.info(f"Visibility check failed for marketplace {marketplace['id']}: {e}")

async def post_to_marketplace(client: TelegramClient, ad, marketplace):
    """Attempts a single post. Returns the real destination message link on success,
       or None on any failure (silently skipped)."""
    link, _msg_id, _target = await _post_to_marketplace_core(client, ad, marketplace)
    return link

async def _post_to_marketplace_core(client: TelegramClient, ad, marketplace):
    """Same as post_to_marketplace, but also returns (msg_id, target) so callers
       that need to run their own visibility check (e.g. low_quality_engine.py)
       can do so without duplicating the posting logic. post_to_marketplace()
       above is just a thin wrapper kept 100% behavior-identical for the
       existing caller in run_advertisement_loop."""
    try:
        target = marketplace["chat_id"]
        source_username = ad["source_username"] if "source_username" in ad.keys() else None
        _post_account_id = ad["ad_account_id"]
        if source_username:
            from_peer = await client.get_input_entity(source_username)
        else:
            from_peer = await client.get_input_entity(ad["source_chat_id"])
        to_peer = await client.get_input_entity(target)

        if not marketplace["is_forum"]:
            result = await client(ForwardMessagesRequest(
                from_peer=from_peer, id=[ad["source_message_id"]], to_peer=to_peer,
                top_msg_id=None, random_id=[random.getrandbits(63)]
            ))
            try:
                import restriction_monitor
                restriction_monitor.record_marketplace_success(_post_account_id, marketplace["id"])
            except Exception:
                pass
            new_msg_id = _extract_new_message_id(result)
            if new_msg_id and await db.should_check_visibility(marketplace["id"]):
                asyncio.create_task(_check_visibility_later(client, marketplace, new_msg_id, target))
            return _build_message_link(marketplace, new_msg_id), new_msg_id, target

        candidates = await db.get_ranked_topics(marketplace["id"], ad["category"])
        if not candidates:
            candidates = [None]  # no topics known/open — try the general/default thread

        for top_msg_id in candidates[:4]:  # cap attempts to limit flood risk on one marketplace
            try:
                result = await client(ForwardMessagesRequest(
                    from_peer=from_peer, id=[ad["source_message_id"]], to_peer=to_peer,
                    top_msg_id=top_msg_id, random_id=[random.getrandbits(63)]
                ))
                try:
                    import restriction_monitor
                    restriction_monitor.record_marketplace_success(_post_account_id, marketplace["id"])
                except Exception:
                    pass
                new_msg_id = _extract_new_message_id(result)
                if new_msg_id and await db.should_check_visibility(marketplace["id"]):
                    asyncio.create_task(_check_visibility_later(client, marketplace, new_msg_id, target))
                return _build_message_link(marketplace, new_msg_id), new_msg_id, target
            except (FloodWaitError, ChatWriteForbiddenError, UserBannedInChannelError):
                raise
            except Exception:
                continue  # this topic rejected the post, try the next candidate

        return None, None, None
    except FloodWaitError:
        return None, None, None
    except (ChatWriteForbiddenError, UserBannedInChannelError):
        try:
            import restriction_monitor
            await restriction_monitor.record_marketplace_ban(ad["ad_account_id"], marketplace["id"])
        except Exception as e:
            print(f"[engine] restriction_monitor recording failed: {e}")
        return None, None, None
    except Exception as e:
        logger.info(f"Skipped marketplace {marketplace['id']}: {e}")
        return None, None, None

_pace_counters = {}  # ad_id -> number of posts made, drives the interval rotation.
                      # Kept independent of the marketplace list/index on purpose — see below.

async def run_advertisement_loop(ad):
    """One continuous cycle for a single advertisement. Runs until status changes to 'stopped'."""
    ad_id = ad["id"]
    client = await get_client(ad["ad_account_id"])
    all_marketplaces = await db.get_list_marketplaces(ad["marketplace_list_id"])
    if not all_marketplaces:
        logger.warning(f"Ad {ad_id} has an empty marketplace list, stopping.")
        return

    # Skip marketplaces auto-demoted for consistently burying posts — but never
    # end up with zero marketplaces to post to, so fall back to the full list
    # if filtering would empty it out entirely.
    marketplaces = [m for m in all_marketplaces if m["quality_tier"] != "low"] or all_marketplaces

    index = ad["current_index"] % len(marketplaces)
    pace = _pace_counters.setdefault(ad_id, 0)

    startup_delay = random.uniform(5, 90)
    await asyncio.sleep(startup_delay)

    try:
        while True:
            # re-check status each cycle in case it was stopped/replaced
            current = await db.get_active_advertisements()
            if not any(a["id"] == ad_id for a in current):
                break

            # Re-fetch periodically so newly-demoted marketplaces drop out of
            # rotation without needing to wait for this ad to restart.
            all_marketplaces = await db.get_list_marketplaces(ad["marketplace_list_id"])
            marketplaces = [m for m in all_marketplaces if m["quality_tier"] != "low"] or all_marketplaces
            index = index % len(marketplaces)

            marketplace = marketplaces[index]
            posted_link = await post_to_marketplace(client, ad, marketplace)
            if posted_link:
                await db.log_success(
                    ad["ad_account_id"],
                    marketplace["id"],
                    posted_link,
                )
                logger.info(f"Posted to {marketplace['chat_username']}")

            index = (index + 1) % len(marketplaces)
            await db.update_ad_index(ad_id, index)

            # Pace is a dedicated, ever-incrementing counter — deliberately NOT
            # derived from `index` or `len(marketplaces)`. Those change constantly
            # as marketplaces get auto-demoted to "low" quality and drop out of
            # this loop, and tying the interval to them caused the rotation to
            # collapse toward the 60s bucket far more often than 120/180/240s
            # (exactly reproduced against live data: a 29-marketplace list is not
            # a multiple of 4, so `index % 4` was landing on 0 disproportionately,
            # and kept getting worse as more marketplaces were demoted over time —
            # this is what was causing near-constant 1-minute posting). This
            # counter always cycles a true 60 -> 120 -> 180 -> 240 -> repeat,
            # independent of marketplace count.
            pace += 1
            interval = POST_INTERVAL_CYCLE[pace % len(POST_INTERVAL_CYCLE)]
            await asyncio.sleep(interval)
    finally:
        _pace_counters.pop(ad_id, None)

_running_ad_ids = set()

async def _run_with_restart(ad):
    """Wraps run_advertisement_loop so ANY unexpected error (connection drop, etc.)
       restarts the loop after a short delay instead of silently killing the ad forever."""
    ad_id = ad["id"]
    while True:
        try:
            await run_advertisement_loop(ad)
            break  # loop exited cleanly (ad stopped/replaced) — do not restart
        except Exception as e:
            logger.info(f"Advertisement id={ad_id} crashed unexpectedly: {e} — restarting in 15s")
            await asyncio.sleep(15)
            fresh = await db.get_active_advertisements()
            ad = next((a for a in fresh if a["id"] == ad_id), None)
            if not ad:
                break  # ad no longer active, stop retrying

async def watch_for_new_ads():
    """Polls the database for newly created active ads and spawns tasks for them,
       so customers can set advertisements live without restarting the engine."""
    while True:
        try:
            ads = await db.get_active_advertisements()
            for ad in ads:
                if ad["id"] not in _running_ad_ids:
                    _running_ad_ids.add(ad["id"])
                    asyncio.create_task(_run_with_restart(ad))
                    logger.info(f"Picked up new advertisement id={ad['id']}")
        except Exception as e:
            logger.info(f"watch_for_new_ads error: {e}")
        await asyncio.sleep(10)

async def start_engine():
    """Boots one asyncio task per active advertisement, then keeps watching for new ones."""
    await db.init_db()
    ads = await db.get_active_advertisements()
    tasks = []
    for ad in ads:
        _running_ad_ids.add(ad["id"])
        tasks.append(asyncio.create_task(_run_with_restart(ad)))

    async def cleanup_loop():
        while True:
            await db.cleanup_old_logs()
            await asyncio.sleep(60)

    tasks.append(asyncio.create_task(cleanup_loop()))
    tasks.append(asyncio.create_task(watch_for_new_ads()))

    # Separate, independent staggered sweet-spot scheduler for marketplaces
    # already auto-demoted to 'low' quality (skipped entirely by the loop
    # above). Runs on its own task/schedule and cannot affect the main
    # rotation. (Replaces the older low_quality_engine.py adaptive-ladder
    # module — that file is still on disk but no longer started here.)
    import low_quality_stagger
    tasks.append(asyncio.create_task(low_quality_stagger.watch_low_quality_marketplaces()))

    await asyncio.gather(*tasks)

if __name__ == "__main__":
    asyncio.run(start_engine())